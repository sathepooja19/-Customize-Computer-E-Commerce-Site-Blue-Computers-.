from django.contrib import auth
from django.contrib.auth.forms import UserCreationForm
from django.http.response import HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect, render, HttpResponse
from datetime import date, datetime, timedelta
from home.models import Contact
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.contrib.auth import logout
from .forms import CreateUserForm
from django.utils.datastructures import MultiValueDictKeyError
from .models import FilesUpload, buildcart, orderStatus, orders, cart, productCategory
from .models import firstCarousel, secondCarousel, thirdCarousel, product, userAddres
from django.db.models import Sum
import random

globalProductQuantity = 1


def newlogin(request):
    try:
        if request.method == 'POST':
            username = request.POST['username']
            password = request.POST['password']
            user = auth.authenticate(username=username, password=password)
            if user:
            
                auth.login(request, user)
            # messages.info(request, 'welcome')
                return redirect('/latest')
            else:
                
                return redirect('/newlogin')
                messages.info(request, 'Invalid Password!')

        else:
            return render(request, 'newlogin.html')
    except MultiValueDictKeyError:
        username = False
        password = False
      
    return render(request, "newlogin.html")


def newregister(request):
    i = 0
    

    print('user created000')
    if request.method == 'POST':
        print('user created1')
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']

        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'Username Takem')
                return redirect('/latest')
            elif User.objects.filter(email=email).exists():
                print('email exist')
                return redirect('/latest')
            else:
                print('user created1')
                user = User.objects.create_user(
                    username=username, password=password1, email=email, first_name=first_name, last_name=last_name)
                user.save()
                messages.info(request, 'User registered')
                user = auth.authenticate(username=username, password=password1)
                auth.login(request, user)
                return redirect('/latest')

        else:
            messages.info(request, 'password not matching')
            return redirect('newregister')
    
    return render(request, 'newlogin.html')


# Create your views here.
def index(request):
    first = firstCarousel.objects.all()
    second = secondCarousel.objects.all()
    third = thirdCarousel.objects.all()
    products = product.objects.all()
    cartProductCount = cart.objects.all().count()
    context1 = {'firstCarousel': first, 'secondCarousel': second,
                'thirdCarousel': third, 'allProducts': products, 'cartProductCount' : cartProductCount}
    

    return render(request, 'index.html',  context1)


def logout(request):
    auth.logout(request)
    messages.warning(request, 'You have been Successfully Logged Out..!')
    return redirect("/latest")


def latest(request):
    return redirect('index')


def about(request):
    return render(request, 'index.html')


def album(request):
    return render(request, 'album.html')


def populer(request):
    return render(request, 'populer.html')


def contacts(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        contact = request.POST.get('phone_number')
        query = request.POST.get('query')
        contact = Contact(name=name, email=email, phone=contact,
                          desc=query, date=datetime.today())
        contact.save()
        messages.success(request, name+' Your message has been sent.')
    cartProductCount = cart.objects.all().count()
    return render(request, 'contact.html',{'cartProductCount' : cartProductCount})


def productView(request, pk):
    productDetails = product.objects.get(id=pk)
    cartProductCount = cart.objects.all().count()
    context = {'showProduct': productDetails, 'cartProductCount' : cartProductCount}
    return render(request, 'productView.html', context)


def buynow(request, pk2):
    uid = request.user
    try:
        if request.method == "POST":
            contact = request.POST.get('phone')
            address = request.POST.get('street')
            city = request.POST.get('city')
            state = request.POST.get('state')
            pinCode = request.POST.get('zip')
            if userAddres.objects.filter(user=uid).exists():
                updateAddress = userAddres.objects.get(user=uid)
                updateAddress.contact = contact
                updateAddress.address = address
                updateAddress.city = city
                updateAddress.state = state
                updateAddress.pinCode = pinCode
                updateAddress.save()
            else:
                print("else1")
                address = userAddres(contact=contact, address=address, city=city,
                                     state=state, pinCode=pinCode, country="India", user=uid)
                address.save()
            messages.success(request, 'Address Saved')

        productID = product.objects.get(id=pk2)
        try:
            addressID = userAddres.objects.get(user=uid)

        except Exception as e:
            print(e)
            addressID = 0
            print("except1")
            context = {'product': productID, 'address': addressID}
            return render(request, 'buynow.html', context)
        cartProductCount = cart.objects.all().count()
        context = {'product': productID, 'address': addressID, 'cartProductCount' : cartProductCount}
        return render(request, 'buynow.html', context)
    except Exception as e:
        productID = product.objects.get(id=pk2)
        print(e)
        print("in outer expect")
        cartProductCount = cart.objects.all().count()
        context = {'product': productID, 'cartProductCount' : cartProductCount}
        return render(request, 'buynow.html', context)
        messages.success(request, 'Address Exception')


def orderReceipt(request, pk3):
    Quantity = request.POST.get('quantity')
    print("here is the Q ")
    print(globalProductQuantity)
    productID = product.objects.get(id=pk3)
    userID = request.user
    orderId = random.randint(12354, 98567)
    orderDate = date.today()
    orderQuantity = 1
    orderExpectedDiliveryDate = orderDate + timedelta(days=10)
    order = orders(productID=productID, userID=userID, orderID=orderId,
                   orderDate=orderDate, orderQuantity=orderQuantity,
                   orderExpectedDiliveryDate=orderExpectedDiliveryDate)
    order.save()
    return redirect('orderplaced')


def allorders(request):
    oID = orders.objects.filter(userID=request.user)
    cartProductCount = cart.objects.all().count()
    return render(request, "allorders.html", {'orders': oID,'cartProductCount':cartProductCount})


def orderplaced(request):
    return render(request, "orderplaced.html")


def usercart(request):
    userID = request.user
    cartID = cart.objects.filter(userID=userID)
    total = cart.objects.aggregate(Sum('total'))

    addressID=0

    if userAddres.objects.filter(user=userID).exists():
        addressID = userAddres.objects.get(user=userID)
    
    return render(request, "cart.html", {'cartID': cartID, 'total': total, 'address': addressID})


def removeproductfromcart(request, pk):
    removeproduct = cart.objects.filter(id=pk)
    removeproduct.delete()
    return redirect('/cart')

def removeproductfrombuildcart(request, pk):
    removeproduct = buildcart.objects.filter(id=pk)
    removeproduct.delete()
    return redirect('/viewbuildcart')

def addtocart(request, pk):
    if request.method == "POST":
        productID = product.objects.get(id=pk)
        userID = request.user
        DT = date.today()
        quantity = request.POST.get('quantity')
        appPrices = product._meta.get_field('product_price')
        price = int(appPrices.value_from_object(productID))
        total = int(quantity) * int(price)

        quantity = int(quantity)
    
        if cart.objects.filter(productID=productID).exists():
            cartID = cart.objects.get(productID=productID)
            oldQuantity = cartID.quantity
            newQuantity = oldQuantity + quantity
            total = newQuantity * price
            cartID.quantity = newQuantity
            cartID.total = total
            cartID.save()
            
            cartProductCount = cart.objects.all().count()
            context = {'showProduct': productID, 'cartProductCount' : cartProductCount}
            return render(request, 'productView.html', context)
        else:
            addedtocart = cart(productID=productID, userID=userID,
                           date=DT, quantity=quantity, total=total)
            addedtocart.save()  

            cartProductCount = cart.objects.all().count()
            context = {'showProduct': productID, 'cartProductCount' : cartProductCount}
            return render(request, 'productView.html', context)
    else:
        return HttpResponse('Something Went Wrong..!')
    

def allcartaddtoorders(request):
    userID = request.user
    allcart = cart.objects.filter(userID = userID)
    for i in allcart:
        rderId = random.randint(12354, 98567)
        orderExpectedDiliveryDate = i.date + timedelta(days=10)
        cartID = cart.objects.filter(productID = i.productID)
        order = orders(productID=i.productID, userID=userID, orderID=rderId,
                   orderDate=i.date, orderQuantity=i.quantity,
                   orderExpectedDiliveryDate=orderExpectedDiliveryDate)
        order.save()
        cartID.delete()
    return redirect('/orderplaced')


def allbuildcartaddtoorders(request):
    userID = request.user
    allcart = buildcart.objects.filter(userID = userID)
    for i in allcart:
        rderId = random.randint(12354, 98567)
        orderExpectedDiliveryDate = i.date + timedelta(days=10)
        buildCartID = buildcart.objects.filter(productID = i.productID)
        order = orders(productID=i.productID, userID=userID, orderID=rderId,
                   orderDate=i.date, orderQuantity=i.quantity,
                   orderExpectedDiliveryDate=orderExpectedDiliveryDate)
        order.save()
        buildCartID.delete()
    return redirect('/orderplaced')



def changeaddress(request):
    uid = request.user
    if request.method == "POST":
            contact = request.POST.get('phone')
            address = request.POST.get('street')
            city = request.POST.get('city')
            state = request.POST.get('state')
            pinCode = request.POST.get('zip')
            if userAddres.objects.filter(user=uid).exists():
                updateAddress = userAddres.objects.get(user=uid)
                updateAddress.contact = contact
                updateAddress.address = address
                updateAddress.city = city
                updateAddress.state = state
                updateAddress.pinCode = pinCode
                updateAddress.save()
            else:
                address = userAddres(contact=contact, address=address, city=city,
                                     state=state, pinCode=pinCode, country="India", user=uid)
                address.save()
            messages.success(request, 'Address Saved')
    return redirect('cart/')


def address(request):
    return render(request, 'address.html')


def build(request):
    productCategories = productCategory.objects.all()
    cartProductCount = cart.objects.all().count()
    return render (request,'build.html',{'categories' : productCategories,'cartProductCount' : cartProductCount})

def produtByCategory(request,pk):
    try:
        if pk == 0:
            products = product.objects.all()
            productCategories = productCategory.objects.all()
        else:
            products = product.objects.filter(product_category = pk)
            productCategories = productCategory.objects.all()
            cartProductCount = cart.objects.all().count()
        return render (request,'build.html',{'products' : products,'categories' : productCategories,'cartProductCount' : cartProductCount})
    except Exception as e:
        print(e)        


def viewbuildcart(request):
    userID = request.user
    cartID = buildcart.objects.filter(userID=userID)
    total = buildcart.objects.aggregate(Sum('total'))

    addressID=0

    if userAddres.objects.filter(user=userID).exists():
        addressID = userAddres.objects.get(user=userID)
    
    return render(request, "viewbuildcart.html", {'cartID': cartID, 'total': total, 'address': addressID})


def buildCart(request,pk):
    productID = product.objects.get(id=pk)
    productCategoryID = productID.product_category
    addedCategories = buildcart.objects.all()
    flag = 0

    if productCategoryID:             
        for cateogry in addedCategories:
            if productCategoryID == cateogry.productID.product_category:
                flag = 1
                break
            
    if flag == 0:
        userID = request.user
        productID = product.objects.get(id=pk)
        DT = date.today()
        quantity = 1
        total = quantity * productID.product_price
        productCategoryID = productID.product_category
        Buildcart = buildcart(productID = productID,userID = userID,date = DT,quantity = quantity, total = total,productCategoryID=productCategoryID)
        Buildcart.save()
    else:
        messages.warning(request, 'You Already added this Cateogery type Product in Your Buildcart If you want Change Please Remove it from Buildcart..!')
    return redirect("/build")
    
def rateproduct(request):
    return render(request,"RateProduct.html")
