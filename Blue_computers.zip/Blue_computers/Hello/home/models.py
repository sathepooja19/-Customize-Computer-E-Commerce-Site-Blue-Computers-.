from enum import unique
from django.contrib import messages
from django.contrib.auth.models import User
from django.db import models
from django.db.models.base import Model
from django.db.models.deletion import CASCADE
from django.db.models.fields import DateTimeField
from django.http import HttpResponse
from django.shortcuts import render
from django.urls import reverse
from requests import request
import requests


class FilesUpload(models.Model):
    file = models.FileField()

# Create your models here.
class Contact(models.Model):
    name    = models.CharField(max_length=127)
    email   = models.CharField(max_length=127)
    phone   = models.CharField(max_length=12)
    desc    = models.TextField()
    date    = models.DateField()

    def __str__(self):
        return self.name

class productCategory(models.Model):
    categoryName = models.CharField(max_length=63)

    def __str__(self):
        return self.categoryName

class product(models.Model):
    product_image = models.ImageField(blank = True,upload_to='product_image')
    product_name = models.CharField(max_length = 255)
    product_price = models.CharField(max_length = 255)
    product_MRP = models.CharField(max_length = 255)
    product_description = models.TextField()
    product_rating = models.IntegerField()
    product_category = models.ForeignKey(productCategory,on_delete=CASCADE)

    def get_absolute_url(self):
        return reverse('productView', args=[str(self.id)])

    
    def __str__(self):
        return self.product_name
    
   
class firstCarousel(models.Model):
    carousel_image = models.ImageField(blank = True,upload_to='carousel_image')
    product = models.ForeignKey(product,on_delete=CASCADE)

class secondCarousel(models.Model):
    carousel_image = models.ImageField(blank = True,upload_to='carousel_image')
    product = models.ForeignKey(product,on_delete=CASCADE)

class thirdCarousel(models.Model):
    carousel_image = models.ImageField(blank = True,upload_to='carousel_image')
    product = models.ForeignKey(product,on_delete=CASCADE)


class userAddres(models.Model):
    pinCode = models.CharField(max_length=127)  
    contact = models.CharField(max_length=127)  
    address = models.CharField(max_length=127)  
    city = models.CharField(max_length=127)
    country = models.CharField(max_length=127)
    state = models.CharField(max_length= 127,null=True)  
    user = models.ForeignKey(User,on_delete=CASCADE)
    
    def __str__(self):
        return self.city
   

class buynow(models.Model):
    product = models.ForeignKey(product,on_delete=CASCADE)

    def get_absolute_url(self):
        return reverse('buynow', args=[str(self.id)])    



class orderStatus(models.Model):
    status = models.CharField(max_length=31)

    def __str__(self):
        return self.status
    


class orders(models.Model):
    orderID = models.IntegerField()
    productID = models.ForeignKey(product,on_delete=CASCADE)
    userID = models.ForeignKey(User,on_delete=CASCADE)
    orderDate = models.DateField()
    orderQuantity = models.IntegerField()
    orderStatus = models.ForeignKey(orderStatus,on_delete=CASCADE,default=2)
    orderExpectedDiliveryDate = models.DateField(null=True)
    
    
    def get_absolute_url(self):
        return reverse('orderReceipt', args=[str(self.productID)])    
  


class cart(models.Model):
    productID = models.ForeignKey(product,on_delete=CASCADE,default=2)
    userID = models.ForeignKey(User,on_delete=CASCADE,default=24)
    date = models.DateField()
    quantity = models.IntegerField()
    total = models.IntegerField()

    def __str__(self):
        return self.productID.product_name
        
    
class buildcart(models.Model):
    productID = models.ForeignKey(product,on_delete=CASCADE,default=2)
    userID = models.ForeignKey(User,on_delete=CASCADE,default=24)
    date = models.DateField()
    quantity = models.IntegerField()
    total = models.IntegerField(default=0)
    productCategoryID = models.ForeignKey(productCategory,on_delete=CASCADE,default=1)

    def __str__(self):
        return self.productID.product_name

class review(models.Model):
    productID = models.ForeignKey(product,on_delete=CASCADE)
    userID    = models.ForeignKey(User,on_delete=CASCADE)
    rating    = models.IntegerField()
    review    = models.TextField(max_length=2047)
    # photos    = models.ImageField(blank = True,upload_to='Review_Images',null=True)
    
    def __str__(self):
        return self.productID.product_name
    