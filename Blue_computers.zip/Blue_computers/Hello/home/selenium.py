
import requests #help to get url directed
from bs4 import BeautifulSoup #help to scrap data

URL = "https://www.amazon.in/Computer-Intel-Core-Processor-Keyboard-Warranty_01/dp/B093R9PHQS/ref=sr_1_3?dchild=1&keywords=gaming+computers&qid=1629711873&sr=8-3"

#Copy url of product

headers = {"user-Agents" : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36'}

page = requests.get(URL , headers= headers)
soup = BeautifulSoup(page.content , 'html.parser')

title = soup.find(class_ = "a-size-large product-title-word-break")

URL = "https://www.amazon.in/Computer-Intel-Core-Processor-Keyboard-Warranty_01/dp/B093R9PHQS/ref=sr_1_3?dchild=1&keywords=gaming+computers&qid=1629711873&sr=8-3"

headers = {"user-Agents" : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36'}
page = requests.get(URL , headers= headers)
soup = BeautifulSoup('<span id="priceblock_ourprice" class="a-size-medium a-color-price priceBlockBuyingPriceString">₹29,500.00</span>', 'html.parser')
price = soup.span.text
tk = 'tusdks'

print (type(title))
print (type(price))
title=title.get_text()
title=str(title)
print(price)
price=price
#price=int(price)
# Create your views here.  
def index(request):
    context = {
        'variable' : "this is sent",
      #  'Tushar' : title,
        'product_1_Name' : title,
        'product_2_price' : price

    }
